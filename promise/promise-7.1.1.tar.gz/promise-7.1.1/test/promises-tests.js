var tests = require('promises-aplus-tests');
var adapter = require('./adapter-a');

tests.mocha(adapter);